/**
 * The bounded-read file handle slice of a ZenFS promises API.
 *
 * @since 0.1.0
 */

/**
 * The bounded-read slice shared by ZenFS and Node file handles.
 *
 * @category models
 * @since 0.1.0
 */
export interface ZenFsFileHandleLike {
  readonly read: (
    buffer: Uint8Array,
    offset: number,
    length: number,
    position: number
  ) => Promise<{ readonly bytesRead: number }>
  readonly close: () => Promise<void>
}
