// Deep reviewed and polished by a human on 2026-08-10.

/**
 * Runtime identity shared by flow interfaces and constructors.
 *
 * @private
 * @since 4.0.0
 */
export const TypeId = "~effect/flow/Flow"
