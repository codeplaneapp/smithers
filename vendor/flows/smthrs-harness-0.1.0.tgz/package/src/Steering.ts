/**
 * Turn-boundary steering values and their source contract.
 *
 * Governing designs: `docs/specs/Concepts/Notification Queue.md` and
 * `docs/specs/Specs/Harness.md`.
 *
 * @since 0.1.0
 */
import * as ModelRequest from "@smthrs/model/ModelRequest"
import { Context, Effect, Layer, Schema } from "effect"
import type { HarnessError } from "./HarnessError.ts"

/**
 * The boundary at which a transcript insertion may be promoted.
 *
 * @category models
 * @since 0.1.0
 */
export type Delivery = "steer" | "queue"

/**
 * A transcript insertion promoted at the next turn boundary.
 *
 * @category models
 * @since 0.1.0
 */
export interface SteerInsert {
  readonly _tag: "Insert"
  readonly delivery: "steer"
  readonly admittedAt: number
  readonly message: ModelRequest.Message
}

/**
 * A transcript insertion promoted only when the run would otherwise go idle.
 *
 * @category models
 * @since 0.1.0
 */
export interface QueueInsert {
  readonly _tag: "Insert"
  readonly delivery: "queue"
  readonly admittedAt: number
  readonly message: ModelRequest.Message
}

/**
 * A transcript insertion admitted for a future turn.
 *
 * @category models
 * @since 0.1.0
 */
export type Insert = SteerInsert | QueueInsert

/**
 * A model-seat change that applies only after the current turn closes.
 *
 * @category models
 * @since 0.1.0
 */
export interface SeatChange {
  readonly _tag: "SeatChange"
  readonly delivery: "steer"
  readonly admittedAt: number
  readonly seat: string
}

/**
 * A thinking-level change that applies only after the current turn closes.
 *
 * @category models
 * @since 0.1.0
 */
export interface ThinkingChange {
  readonly _tag: "ThinkingChange"
  readonly delivery: "steer"
  readonly admittedAt: number
  readonly thinking: ModelRequest.ReasoningEffort
}

/**
 * An additive active-tool update for a future turn.
 *
 * @category models
 * @since 0.1.0
 */
export interface ActivateTools {
  readonly _tag: "ActivateTools"
  readonly delivery: "steer"
  readonly admittedAt: number
  readonly toolNames: ReadonlyArray<string>
}

/**
 * A serializable steering event.
 *
 * @category models
 * @since 0.1.0
 */
export type Item = Insert | SeatChange | ThinkingChange | ActivateTools

/**
 * An immutable, FIFO queue of steering events.
 *
 * @category models
 * @since 0.1.0
 */
export interface Queue {
  readonly items: ReadonlyArray<Item>
}

/**
 * The values promoted when a turn reaches its close boundary.
 *
 * @category models
 * @since 0.1.0
 */
export interface Drain {
  readonly inserts: ReadonlyArray<ModelRequest.Message>
  readonly seatChanges: ReadonlyArray<SeatChange | ThinkingChange>
  readonly activatedToolNames: ReadonlyArray<string>
  readonly remaining: Queue
  readonly queued: boolean
}

/**
 * The boundary a drain is being attempted at, and whether the run would go
 * idle if nothing were delivered. Followups are held back until it would.
 *
 * @category models
 * @since 0.1.0
 */
export interface BoundaryInput {
  readonly boundary: string
  readonly wouldIdle: boolean
}

const SeatChangeRecord = Schema.Struct({
  _tag: Schema.Literal("SeatChange"),
  delivery: Schema.Literal("steer"),
  admittedAt: Schema.Number,
  seat: Schema.String
})

const ThinkingChangeRecord = Schema.Struct({
  _tag: Schema.Literal("ThinkingChange"),
  delivery: Schema.Literal("steer"),
  admittedAt: Schema.Number,
  thinking: ModelRequest.ReasoningEffort
})

/**
 * The journaled record of one turn-boundary drain.
 *
 * A drain consumes host queue state, so it is a nondeterministic read: the
 * controller journals exactly this projection through `EngineLike.record`,
 * keyed on the frame and boundary, and a re-executed frame replays the record
 * instead of draining an already-drained queue. Everything the controller
 * folds into durable state is here; `remaining` is host queue bookkeeping and
 * deliberately is not.
 *
 * @category schemas
 * @since 0.1.0
 */
export const DrainRecord = Schema.Struct({
  inserts: Schema.Array(ModelRequest.Message),
  seatChanges: Schema.Array(Schema.Union([SeatChangeRecord, ThinkingChangeRecord])),
  activatedToolNames: Schema.Array(Schema.String),
  queued: Schema.Boolean
})

/**
 * The journaled record of one turn-boundary drain.
 *
 * @category models
 * @since 0.1.0
 */
export type DrainRecord = typeof DrainRecord.Type

/**
 * Projects a {@link Drain} into its journaled record.
 *
 * @category conversions
 * @since 0.1.0
 */
export const drainRecord = (drain: Drain): DrainRecord => ({
  inserts: drain.inserts,
  seatChanges: drain.seatChanges,
  activatedToolNames: drain.activatedToolNames,
  queued: drain.queued
})

/**
 * The close-frame facts required to admit one queued follow-up.
 *
 * @category models
 * @since 0.1.0
 */
export interface PromotionState {
  /** The immutable post-cutoff queue snapshot. */
  readonly queue: Queue
  /** Whether closing now would resolve the turn. */
  readonly wouldIdle: boolean
  /** Whether a steer-class insertion already continued this turn. */
  readonly steerContinued: boolean
}

const immutable = (items: ReadonlyArray<Item>): Queue => Object.freeze({ items: Object.freeze([...items]) })

const immutableItem = (item: Item): Item =>
  item._tag === "ActivateTools"
    ? Object.freeze({ ...item, toolNames: Object.freeze([...item.toolNames]) })
    : Object.freeze({ ...item })

/**
 * Creates an empty immutable steering queue.
 *
 * @category constructors
 * @since 0.1.0
 */
export const empty = (): Queue => immutable([])

/**
 * Appends an item without mutating the prior queue.
 *
 * @category operations
 * @since 0.1.0
 */
export const enqueue = (queue: Queue, item: Item): Queue => immutable([...queue.items, immutableItem(item)])

/**
 * Drains only items admitted at or before the turn's fixed cutoff.
 *
 * @category operations
 * @since 0.1.0
 */
export const drainAtClose = (queue: Queue, cutoff: number): Drain => {
  const inserts: Array<ModelRequest.Message> = []
  const seatChanges: Array<SeatChange | ThinkingChange> = []
  const activatedToolNames = new Set<string>()
  const remaining: Array<Item> = []
  for (const item of queue.items) {
    if (item.delivery === "queue" || item.admittedAt > cutoff) {
      remaining.push(item)
      continue
    }
    switch (item._tag) {
      case "Insert":
        inserts.push(item.message)
        break
      case "SeatChange":
      case "ThinkingChange":
        seatChanges.push(item)
        break
      case "ActivateTools":
        for (const name of item.toolNames) {
          activatedToolNames.add(name)
        }
        break
    }
  }
  return {
    inserts: Object.freeze(inserts),
    seatChanges: Object.freeze(seatChanges),
    activatedToolNames: Object.freeze([...activatedToolNames]),
    remaining: immutable(remaining),
    queued: false
  }
}

/**
 * Returns the oldest queued insertion only when the current turn would
 * otherwise resolve. Promotion persistence is owned by the queue source.
 *
 * @category operations
 * @since 0.1.0
 */
export const promoteAtIdle = (state: PromotionState): QueueInsert | undefined => {
  if (!state.wouldIdle || state.steerContinued) return undefined
  return state.queue.items.find((item): item is QueueInsert => item._tag === "Insert" && item.delivery === "queue")
}

/** Drains steer-class items and, only at idle, one queued follow-up.
 * @category operations
 * @since 0.1.0
 */
export const drainBoundary = (queue: Queue, input: BoundaryInput): Drain => {
  const cutoff = queue.items.reduce(
    (value, item) => item.delivery === "steer" ? Math.max(value, item.admittedAt) : value,
    -1
  )
  const drained = drainAtClose(queue, cutoff)
  const promoted = promoteAtIdle({
    queue: drained.remaining,
    wouldIdle: input.wouldIdle,
    steerContinued: drained.inserts.length > 0
  })
  if (promoted === undefined) return drained
  return {
    ...drained,
    inserts: [...drained.inserts, promoted.message],
    remaining: immutable(drained.remaining.items.filter((item) => item !== promoted)),
    queued: true
  }
}

/**
 * Source of a serializable steering-queue snapshot. Storage and persistence
 * promotion are deliberately supplied by the host.
 *
 * @category services
 * @since 0.1.0
 */
export interface Source {
  readonly read: () => Effect.Effect<Queue, HarnessError>
  readonly drain: (input: BoundaryInput) => Effect.Effect<Drain, HarnessError>
}

/**
 * The methods {@link make} needs to build a {@link Source}.
 *
 * @category models
 * @since 0.1.0
 */
export interface SourceInput {
  readonly read: () => Effect.Effect<Queue, HarnessError>
  readonly drain: (input: BoundaryInput) => Effect.Effect<Drain, HarnessError>
}

/**
 * Service tag for the external steering queue source.
 *
 * @category services
 * @since 0.1.0
 */
export const Source: Context.Service<Source, Source> = Context.Service("/harness/Steering/Source")

/**
 * Constructs a steering source service.
 *
 * @category constructors
 * @since 0.1.0
 */
export const make = (implementation: SourceInput): Source => Source.of(implementation)

/**
 * Creates a source that always returns an empty queue.
 *
 * @category constructors
 * @since 0.1.0
 */
export const makeNoop = (overrides: Partial<Source> = {}): Source =>
  make({
    read: Effect.fn("Steering.Source.read")(() => Effect.succeed(empty())),
    drain: Effect.fn("Steering.Source.drain")(() =>
      Effect.succeed({
        inserts: [],
        seatChanges: [],
        activatedToolNames: [],
        remaining: empty(),
        queued: false
      })
    ),
    ...overrides
  })

/**
 * Provides a steering source as a layer.
 *
 * @category layers
 * @since 0.1.0
 */
export const layer = (implementation: SourceInput): Layer.Layer<Source> => Layer.succeed(Source)(make(implementation))

/**
 * Provides an empty steering source as a layer.
 *
 * @category layers
 * @since 0.1.0
 */
export const layerNoop = (overrides: Partial<Source> = {}): Layer.Layer<Source> =>
  Layer.succeed(Source)(makeNoop(overrides))
